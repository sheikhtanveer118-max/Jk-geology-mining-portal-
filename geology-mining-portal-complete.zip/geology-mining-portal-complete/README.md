# Geology & Mining Digital Portal
Independent implementation based on the supplied reference structure and e-Challan information.
Run: `npm install`, configure `.env`, then `npm run db:generate`, `npm run db:migrate`, `npm run db:seed`, `npm run dev`.
Before production add real authentication, HTTPS, rate limiting, backups, PDF/QR storage, authorized branding and authorized departmental data.
